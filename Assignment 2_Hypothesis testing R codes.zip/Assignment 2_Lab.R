attach(LabTAT)
##Normality test
shapiro.test(V1)
shapiro.test(V2)
shapiro.test(V3)
shapiro.test(V4)
##Variance test
var.test(V1,V2)
var.test(V1,V3)
var.test(V1,V4)
var.test(V2,V3)
var.test(V2,V4)
var.test(V3,V4)
##ANOVA test
Lab_stacked <- stack(LabTAT)
View(Lab_stacked)
anova <- aov(values~ind,data = Lab_stacked)
summary(anova)
