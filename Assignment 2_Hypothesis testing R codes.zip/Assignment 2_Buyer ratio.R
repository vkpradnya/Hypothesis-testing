attach(BuyerRatio)
##Normality test
stacked_Buyer <- stack(BuyerRatio)
View(stacked_Buyer)
attach(stacked_Buyer)
shapiro.test(values)
# P value <0.05, P low null go, hence reject null hypothesis
## Chi-Square test
chiquare <- chisq.test(values)
chiquare
# P vlaue < 0.05, P low null Go. Hence we reject null hypothesis.
#Conclusion: Male Female ratio in all regions are not equal