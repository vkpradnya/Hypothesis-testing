t1 <- ifelse(`Costomer+OrderForm`=="Defective",0,1)
t2 <- data.frame(t1)
stack_t2 <- stack(t2)
View(stack_t2)
attach(stack_t2)
## Ch squared test
chisq_t2 <- chisq.test(values,ind)
chisq_t2

## P >0.05. P High Null fly. We fail to reject null Hypothesis.