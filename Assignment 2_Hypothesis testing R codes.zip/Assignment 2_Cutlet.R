View(Cutlets)
#### Y Continuous & X Discrete (only 2 variables)
### Normality test >> check P value
shapiro.test(Cutlets$Unit.A)
shapiro.test(Cutlets$Unit.B)
# If P Values are greater than 0.05, fail to reject null hypothesis. Data are normal. 
### Variance test
var.test(Cutlets$Unit.A,Cutlets$Unit.B)
# If P values are greater than 0.05, fail to reject null hypothesis. Variance are equal.
### 2 Sample T test
t.test(Cutlets$Unit.A,Cutlets$Unit.B,alternative = "two.sided",var.equal = TRUE)
# If P value is greater than 0.05, fail to reject null hypothesis. Hence there is no defference in diameter of cutlets of Unit A&B