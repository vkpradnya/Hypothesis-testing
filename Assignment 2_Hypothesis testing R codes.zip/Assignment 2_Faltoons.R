attach(Faltoons)
dataframe <- data.frame(Faltoons)
dataframe
t1 <- table(Faltoons)
t1
prop.test(t1)
## P value is > .05 hence P High Null fly. We fail to reject null hypothesis. 
##% of male & female  walking into store do not differ based on day of the week.

